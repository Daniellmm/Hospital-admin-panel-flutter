import 'package:flutter/material.dart';
import 'package:hmsapp/widgets/custom.dart';

class AuthenticationPage extends StatelessWidget {
  // const OverViewPage ({super.key});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: CustomText(text: "Authentication"),
    );
  }
}
