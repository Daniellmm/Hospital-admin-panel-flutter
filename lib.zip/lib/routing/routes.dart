const OverViewPageRoute = "Dashboard";
const PatientsPageRoute = "Add Patients";
const BookingPageRoute = "Book Appointment";
const ConsultPageRoute = "Consultation";
const PharmacyPageRoute = "Pharmacy";
const PaymentPageRoute = "Payment";
const AuthenticationPageRoute = "Authentication";


List sideMenuItems = [
OverViewPageRoute,
PatientsPageRoute, 
BookingPageRoute,
ConsultPageRoute,
PharmacyPageRoute,
PaymentPageRoute,
AuthenticationPageRoute
];