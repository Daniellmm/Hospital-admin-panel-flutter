import 'package:flutter/material.dart';

Color light = Color(0xFFF7F8FC);
Color lightGrey = Color(0xFFA4A683);
Color dark = Color(0xFF363740);
Color active = Color(0xFF3C19C0);