import 'package:hmsapp/controllers/menu_controller.dart';
import 'package:hmsapp/controllers/navigation_controller.dart';

MenuControllers menuControllers = MenuControllers.instance;
NavigationController navigationController = NavigationController.instance;
